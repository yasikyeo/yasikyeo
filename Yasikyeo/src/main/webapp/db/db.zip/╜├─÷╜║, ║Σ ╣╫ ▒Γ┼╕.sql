drop sequence shop_no_seq;
create sequence shop_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence ceo_no_seq;
create sequence ceo_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence member_no_seq;
create sequence member_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence notice_no_seq;
create sequence notice_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence admin_no_seq;
create sequence admin_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence review_no_seq;
create sequence review_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence reply_no_seq;
create sequence reply_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence qna_no_seq;
create sequence qna_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence faq_no_seq;
create sequence faq_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence product_no_seq;
create sequence product_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence categori_no_seq;
create sequence categori_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence orderlist_no_seq;
create sequence orderlist_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence point_no_seq;
create sequence point_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;

drop sequence orderdet_no_seq;
create sequence orderdet_no_seq
minvalue 1
maxvalue 9999999
increment by 1
start with 1
nocache;


insert into admin(admin_no,admin_id,admin_pwd,admin_name)
values(admin_no_seq.nextval,'admin','admin123','ADMIN');


insert into member(member_no,member_id,member_pwd,member_nickname,member_tel,member_email,member_birth)
values(member_no_seq.nextval,'abcd','1234','����','010-1234-5678','abc@naver.com',12345678);